
//account menu
$(".ac-child").prepend('<span class="ac-dropdown"></span>');
        
$('.ac-dropdown').on('click', function(){
    $(this).toggleClass('ac-opened');
    if ($(this).siblings('ul').hasClass('open')) {
        $(this).siblings('ul').removeClass('open').slideToggle();
        $(this).parent('li').removeClass('active');
    } else {
        $(this).siblings('ul').addClass('open').slideToggle();
        $(this).parent('li').addClass('active');
    }
});

//header fixed on scrol
$(window).scroll(function() {
    if ($(this).scrollTop() > 300) {
        $('.header').addClass("fixed-header");
    } else {
        $('.header').removeClass("fixed-header");
    }
});

//Back to top
$('.scrollToTop').on('click', function() {
    $('html, body').animate({
        scrollTop: 0
    }, 800);
    return false;
});
$(window).scroll(function() {
    if ($(window).scrollTop() > 300) {
        $('.scrollToTop').addClass('back-top');
    } else {
        $('.scrollToTop').removeClass('back-top');
    }
});

//tooltip
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
 });
@php
/*
$layout_page = shop_profile
** Variables:**
- $addresses
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<style>
  .list{
    padding: 5px;
    border-bottom: 1px solid #c5baba;
  }
</style>
<section class="box box-padding">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
    <div class="col-md-9 ">
      @if (count($addresses) ==0)
      <div class="text-danger">
        {{ trans('account.addresses.empty') }}
      </div>
      @else
        
          @foreach($addresses as $address)
          <ul class="address-list">
          @if (sc_config('customer_lastname'))
          <li>
            <span class="list-head">{{ trans('account.first_name') }}:</span> {{ $address['first_name'] }}
          </li>
          <li>
            <span class="list-head">{{ trans('account.last_name') }}:</span> {{ $address['last_name'] }}
          </li>
          @else
          <li>
            <span class="list-head">{{ trans('account.name') }}:</span> {{ $address['first_name'] }}
          </li>
          @endif

          @if (sc_config('customer_phone'))
            <li><span class="list-head">{{ trans('account.phone') }}:</span> {{ $address['phone'] }}</li>
          @endif

          @if (sc_config('customer_postcode'))
            <li><span class="list-head">{{ trans('account.postcode') }}:</span> {{ $address['postcode'] }}</li>
          @endif

          @if (sc_config('customer_address2'))
          <li>
            <span class="list-head">{{ trans('account.address1') }}:</span> {{ $address['address1'] }}
          </li>
          <li>
            <span class="list-head">{{ trans('account.address2') }}:</span> {{ $address['address2'] }}
          </li>
          @else
          <li>
            <span class="list-head">{{ trans('account.address') }}:</span> {{ $address['first_address1'] }}
          </li>
          @endif

          @if (sc_config('customer_country'))
            <li><span class="list-head">{{ trans('account.country') }}:</span> {{ $countries[$address['country']] ?? $address['country'] }}</li>
          @endif
        </ul>

        <ul class="ac-btn-area">
          <li><a title="{{ trans('account.addresses.edit') }}" href="{{ sc_route('customer.update_address', ['id' => $address->id]) }}" data-toggle="tooltip" data-placement="top" data-original-title="Edit Address"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z"/></svg>
          </a></li>

          <li><a href="#" title="{{ trans('account.addresses.delete') }}" class="delete-address" data-id="{{ $address->id }}" data-toggle="tooltip" data-placement="top" data-original-title="Delete Address">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M32 464a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V128H32zm272-256a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zm-96 0a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zm-96 0a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zM432 32H312l-9.4-18.7A24 24 0 0 0 281.1 0H166.8a23.72 23.72 0 0 0-21.4 13.3L136 32H16A16 16 0 0 0 0 48v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16z"/></svg>
          </a></li>

          @if ($address->id == auth()->user()->address_id)
          <li><span title="{{ trans('account.addresses.default') }}" data-toggle="tooltip" data-placement="top" data-original-title="Default Address">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M496 128v16a8 8 0 0 1-8 8h-24v12c0 6.627-5.373 12-12 12H60c-6.627 0-12-5.373-12-12v-12H24a8 8 0 0 1-8-8v-16a8 8 0 0 1 4.941-7.392l232-88a7.996 7.996 0 0 1 6.118 0l232 88A8 8 0 0 1 496 128zm-24 304H40c-13.255 0-24 10.745-24 24v16a8 8 0 0 0 8 8h464a8 8 0 0 0 8-8v-16c0-13.255-10.745-24-24-24zM96 192v192H60c-6.627 0-12 5.373-12 12v20h416v-20c0-6.627-5.373-12-12-12h-36V192h-64v192h-64V192h-64v192h-64V192H96z"/></svg>
          </span></li>
          @endif
        </ul>
        @endforeach          
        
      @endif
    </div>
  </div>
</div>
</section>
@endsection


{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
  <div class="pager-banner">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <div class="banner-content">
                      <h1>{{ $title ?? '' }}</h1>
                      <div class="page-breadcrumb">
                          <ul>
                              <li class="parent"><a href="{{ sc_route('home') }}">{{ trans('front.home') }}</a></li>
                              <li class="parent"><a href="{{ sc_route('customer.index') }}">{{ trans('front.my_account') }}</a></li>
                              <li><span>{{ $title ?? '' }}</span></li>
                          </ul>
                      </div><!-- page breadcrumb end -->
                  </div><!-- banne content end -->
              </div><!-- col end -->
          </div><!-- row end -->
      </div><!-- container end -->
  </div><!-- page banner end -->
</div><!-- box end -->
@endsection
{{-- //breadcrumb --}}



@push('scripts')
<script>
  $('.delete-address').click(function(){
    var r = confirm("{{ trans('account.confirm_delete') }}");
    if(!r) {
      return;
    }
    var id = $(this).data('id');
    $.ajax({
            url:'{{ sc_route("member.delete_address") }}',
            type:'POST',
            dataType:'json',
            data:{id:id,"_token": "{{ csrf_token() }}"},
                beforeSend: function(){
                $('#loading').show();
            },
            success: function(data){
              if(data.error == 0) {
                location.reload();
              }
            }
        });
  });
</script>
@endpush
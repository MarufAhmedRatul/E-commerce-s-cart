@php
/*
$layout_page = shop_profile
** Variables:**
- $customer
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<div class="box box-padding">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-3">
                @include($sc_templatePath.'.account.nav_customer')
            </div>
            <div class="col-12 col-sm-12 col-md-9">
                <div class="card">
                    <div class="card-body min-height-37vh member-index">
                        <p>Wellcome <span> {{ $customer['first_name'] }} {{ $customer['last_name'] }}</span>!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- box end -->
@endsection

@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
</div><!-- box end -->
@endsection
@php
/*
$layout_page = shop_auth
*/
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="box box-padding user-fileds">
    <div class="container">
    <div class="row">
        <div class="col-12 col-sm-12">
            <h2>{{ trans('account.password_forgot') }}</h2>

            <div class="form-area">
                <form class="form-horizontal" method="POST" action="{{ sc_route('password.email') }}" id="form-process">
                    {{ csrf_field() }}
                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                        <label for="email" class="col-md-12 control-label"><i class="fas fa-envelope"></i>
                            {{ trans('customer.email') }}</label>
                        <div class="col-md-12">
                            <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}"
                                required>
                            @if ($errors->has('email'))
                            <span class="help-block">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                            <br />
                            @endif
                            {!! $viewCaptcha ?? ''!!}
                            <button type="submit" name="SubmitLogin" class="btn action-button" id="button-form-process">{{ trans('front.submit_form') }}</button>
                        </div>
                    </div>
                </form>
            </div><!-- form area end -->
        </div>
    </div>
</div>
</section>

@endsection

{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
  </div><!-- box end -->
@endsection
{{-- //breadcrumb --}}

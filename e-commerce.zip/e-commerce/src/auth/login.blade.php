@extends($sc_templatePath.'.layout')

@section('block_main')
<!--form-->
<section class="box box-padding user-fileds">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12">
                <h2>{{ trans('account.title_login') }}</h2>
                <div class="form-area">
                    <form action="{{ sc_route('postLogin') }}" method="post" class="box">
                        {!! csrf_field() !!}
                        <div class="form-group{{ $errors->has('login_email') ? ' has-error' : '' }}">
                            <label for="email" class="control-label">{{ trans('account.email') }}</label>
                            <input class="is_required validate account_input form-control {{ ($errors->has('email'))?"input-error":"" }}"
                                type="text" name="email" value="{{ old('email') }}">
                            @if ($errors->has('email'))
                            <span class="help-block">
                                {{ $errors->first('email') }}
                            </span>
                            @endif
                        </div>
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="control-label">{{ trans('account.password') }}</label>
                            <input class="is_required validate account_input form-control {{ ($errors->has('password'))?"input-error":"" }}"
                                type="password" name="password" value="">
                            @if ($errors->has('password'))
                            <span class="help-block">
                                {{ $errors->first('password') }}
                            </span>
                            @endif
                    
                        </div>
                        <div class="lost_password form-group">
                            <a class="btn btn-link" href="{{ sc_route('forgot') }}">
                                {{ trans('account.password_forgot') }}
                            </a>
                            <a class="btn btn-link" href="{{ sc_route('register') }}">
                                {{ trans('account.title_register') }}
                            </a>
                        </div>
                        <button type="submit" name="SubmitLogin" class="btn action-button">{{ trans('account.login') }}</button>
                    </form>
                </div><!-- form area end -->
            </div>
        </div>
</div>
</section>
<!--/form-->
@endsection

{{-- breadcrumb --}}
@section('breadcrumb')
    <div class="box">
        <div class="pager-banner">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="banner-content">
                            <h1>{{ $title ?? '' }}</h1>
                            <div class="page-breadcrumb">
                                <ul>
                                    <li class="parent"><a href="{{ sc_route('home') }}">{{ trans('front.home') }}</a></li>
                                    <li><span>{{ $title ?? '' }}</span></li>
                                </ul>
                            </div><!-- page breadcrumb end -->
                        </div><!-- banne content end -->
                    </div><!-- col end -->
                </div><!-- row end -->
            </div><!-- container end -->
        </div><!-- page banner end -->
    </div><!-- box end -->
</section>
@endsection
{{-- //breadcrumb --}}

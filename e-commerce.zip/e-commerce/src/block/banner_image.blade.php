@php
$banners = $modelBanner->start()->getBanner()->getData();
$categoriesTop = $modelCategory->start()->getCategoryTop()->getData();
@endphp
<div class="container"> 
  <div class="row">
    <div class="col-md-3 col-sm-12 cat-no-right-pad">
        <div class="category-box">
            <div class="cat-button cat-toggler">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <path d="M17.5 6h-15c-0.276 0-0.5-0.224-0.5-0.5s0.224-0.5 0.5-0.5h15c0.276 0 0.5 0.224 0.5 0.5s-0.224 0.5-0.5 0.5z"></path>
                    <path d="M17.5 11h-15c-0.276 0-0.5-0.224-0.5-0.5s0.224-0.5 0.5-0.5h15c0.276 0 0.5 0.224 0.5 0.5s-0.224 0.5-0.5 0.5z"></path>
                    <path d="M17.5 16h-15c-0.276 0-0.5-0.224-0.5-0.5s0.224-0.5 0.5-0.5h15c0.276 0 0.5 0.224 0.5 0.5s-0.224 0.5-0.5 0.5z"></path>
                </svg>
                <h3>Categories</h3>
            </div><!-- cat button end -->
            <div class="categotires">
                <ul>
                  @if ($categoriesTop->count())
                  @foreach ($categoriesTop as $key => $category)
                    <li><a href="{{ $category->getUrl() }}">{{ $category->title }}</a></li>
                    @endforeach
                  @endif
                </ul>
            </div><!-- categories end -->
        </div><!-- category box end -->
    </div><!-- col end -->
    <div class="col-md-9 col-sm-12">
        <div class="product-search">
            <form action="{{ sc_route('search') }}" method="GET">
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control" placeholder="search products here">
                    <div class="btn-group category-search-dropdown-js ">
                        <div class="dropdown">
                            <button type="button" class="btn btn-cat dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                All Categories
                            </button>
                            <div class="dropdown-menu" role="menu">
                                <ul>
                                    <li data-slug>All Catagories</li>
                                  @if ($categoriesTop->count())
                                  @foreach ($categoriesTop as $key => $category)
                                    <li data-slug="{{ $category->title }}">{{ $category->title }}</li>
                                    @endforeach
                                  @endif
                                </ul>
                            </div><!-- dropdown menu end -->
                        </div><!-- dropdown end -->
                        <button type="submit" class="btn btn-search">
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" >
                                <path d="M18.869 19.162l-5.943-6.484c1.339-1.401 2.075-3.233 2.075-5.178 0-2.003-0.78-3.887-2.197-5.303s-3.3-2.197-5.303-2.197-3.887 0.78-5.303 2.197-2.197 3.3-2.197 5.303 0.78 3.887 2.197 5.303 3.3 2.197 5.303 2.197c1.726 0 3.362-0.579 4.688-1.645l5.943 6.483c0.099 0.108 0.233 0.162 0.369 0.162 0.121 0 0.242-0.043 0.338-0.131 0.204-0.187 0.217-0.503 0.031-0.706zM1 7.5c0-3.584 2.916-6.5 6.5-6.5s6.5 2.916 6.5 6.5-2.916 6.5-6.5 6.5-6.5-2.916-6.5-6.5z"></path>
                            </svg>
                        </button><!-- search button end -->
                    </div><!-- button group end -->
                </div><!-- input group end -->
            </form><!-- search form end -->
        </div><!-- product search end -->

        <div class="site-banner">
            <img src="{{ asset($sc_templateFile.'/images/banner.jpg') }}" alt="banner">
        </div><!-- site banner end -->
    </div><!-- col end -->
</div><!-- row end -->
</div><!-- container end -->


<div class="box">
  <div class="container">
      <div class="row">
          <div class="col-12">
              <div class="site-banner-full">
                  <img src="{{ asset($sc_templateFile.'/images/banner.jpg') }}" alt="banner">
              </div><!-- site banner end -->
          </div><!-- col end -->
      </div><!-- row end -->
  </div><!-- container end -->
</div><!-- box end -->

@push('scripts')

<script>
  //category select option for search
  $('.category-search-dropdown-js .dropdown-menu li').on('click', function(e) {
            var $parent = $(this).closest('.category-search-dropdown-js'),
                slug = $(this).data('slug'),
                name = $(this).text();
            $parent.find('.dropdown-toggle').text($.trim(name));
            $parent.find('input[name="product_cat"]').val(slug);
        });

        //category list show
        $('.cat-button').on('click', function(e) {
            e.preventDefault();
            $(this).closest('.category-box').toggleClass("opened");
        });

        //Category Mobile menu
        $(".has-child").prepend('<span class="has-dropdown"></span>');
        $('.has-dropdown').on('click', function(){
            $(this).toggleClass('submenu-opened');
            if ($(this).siblings('ul').hasClass('open')) {
                $(this).siblings('ul').removeClass('open').slideToggle();
                $(this).parent('li').removeClass('active');
            } else {
                $(this).siblings('ul').addClass('open').slideToggle();
                $(this).parent('li').addClass('active');
            }
        });
</script>

@endpush
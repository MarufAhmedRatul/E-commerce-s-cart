@php
$brands = $modelBrand->start()->getData()
@endphp
@if (!empty($brands))
<div class="product-brands">
    <h3>{{ trans('front.brands') }}</h3> 
    <ul>
        @foreach ($brands as $brand)
            <li><a class="link-tag" href="{{ $brand->getUrl() }}"> {{ $brand->name }}</a></li>
        @endforeach
    </ul>
</div>
<!--/brands_products-->
@endif

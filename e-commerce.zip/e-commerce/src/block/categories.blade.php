@php
$categoriesTop = $modelCategory->start()->getCategoryTop()->getData();
@endphp
@if ($categoriesTop->count())
<div class="product-categories">
  <h3>{{ trans('front.categories') }}</h3>
  <ul>
    @foreach ($categoriesTop as $key => $category)
    <li><a href="{{ $category->getUrl() }}"> {{ $category->title }}</a></li>
    @endforeach
  </ul>
</div> 
@endif
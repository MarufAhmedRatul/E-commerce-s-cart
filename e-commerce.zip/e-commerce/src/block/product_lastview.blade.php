@php
$arrProductsLastView = array();
$lastView = empty(\Cookie::get('productsLastView')) ? [] : json_decode(\Cookie::get('productsLastView'), true);
if ($lastView) {
    arsort($lastView);
}

if ($lastView && count($lastView)) {
    $lastView = array_slice($lastView, 0, sc_config('product_viewed'), true);
    $productsLastView = $modelProduct->start()->getProductFromListID(array_keys($lastView))->getData();
    foreach ($lastView as $pId => $time) {
        foreach ($productsLastView as $key => $product) {
            if ($product['id'] == $pId) {
                $product['timelastview'] = $time;
                $arrProductsLastView[] = $product;
            }
        } 
    }
}
@endphp
@if (!empty($arrProductsLastView))
<div class="product-list">
    <h3>{{ trans('front.products_last_view') }}</h3>
    <!--last_view_product-->
    <ul>
        @foreach ($arrProductsLastView as $productLastView)
        <li>
            <div class="thumb">
                <a href="{{ $productLastView->getUrl() }}">
                    <img src="{{ asset($productLastView->getThumb()) }}" alt="{{ $productLastView->name}}">
                </a>
            </div><!-- thumb end -->
            <div class="product-detail-short">
                <h5><a href="{{ $productLastView->getUrl() }}">{{ $productLastView->name}}</a></h5>
                <div class="price">
                    <span class="amount">
                        {!! $productLastView->showPrice() !!}
                    </span>
                </div><!-- price end -->
            </div><!-- product detail short end -->
        </li>
        @endforeach
    </ul>
</div>
<!--/last_view_product-->
@endif

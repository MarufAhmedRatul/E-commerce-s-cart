@php
$productPromotion = $modelProduct->getProductPromotion()->setRandom()->setLimit(sc_config('product_viewed'))->getData()
@endphp
@if (!empty($productPromotion))

<div class="product-list">
  <h3 >{{ trans('front.products_special') }}</h3>
  <ul>
    @foreach ($productPromotion as $key => $product)
      <li>
        <div class="thumb">
          <a href="{{ $product->getUrl() }}">
            <img src="{{ asset($product->getThumb()) }}" alt="{{ $product->name}}">
          </a> 
        </div><!-- thumb end -->
        <div class="product-detail-short">
          <h5><a href="{{ $product->getUrl() }}">{{ $product->name}}</a></h5>
          <div class="price">
                    <span class="amount">
                        {!! $product->showPrice() !!}
                    </span>
          </div><!-- price end -->
        </div><!-- product detail short end -->
      </li>
    @endforeach
  </ul>
</div>
<!--/product special-->
@endif
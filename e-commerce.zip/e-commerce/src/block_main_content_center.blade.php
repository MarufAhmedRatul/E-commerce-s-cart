<!--main center-->
@section('block_main_content_center')
@show
 <!--//main center-->
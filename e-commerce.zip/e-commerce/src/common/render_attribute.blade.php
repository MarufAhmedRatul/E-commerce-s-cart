
    @if (!empty($details) && count($details))
        @foreach ($details as $groupId => $detailsGroup)
    <tr>
        <th>{!! $groups[$groupId]??'Not found' !!}</th>
        <td>:</td>
        <td>
            @foreach ($detailsGroup as $k => $detail)
            @php
                $valueOption = $detail->name.'__'.$detail->add_price;
            @endphp
            <div class="form-check form-check-inline">
                <input class="form-check-input" {{ (($k == 0) ? "checked" : "") }} type="radio" name="form_attr[{{ $groupId }}]" value="{{ $valueOption }}">
                {!! sc_render_option_price($valueOption) !!}
            </div>
            @endforeach
        </td> 
    </tr>
        @endforeach
    @endif
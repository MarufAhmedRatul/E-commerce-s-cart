@if (!empty($dataTotal) && count($dataTotal))


    <div class="cart_totals">
        <h3 class="title">Cart Totals</h3>
        <table class="table cart-totals">
            @foreach ($dataTotal as $key => $element)
                @if ($element['code']=='total')
            <tr class="cart-subtotal">
                <th>{!! $element['title'] !!}</th>
                <td id="{{ $element['code'] }}">{{$element['text'] }}</td>
            </tr>
                @elseif($element['value'] !=0)
                    <tr class="cart-subtotal">
                        <th>{!! $element['title'] !!}</th>
                        <td  id="{{ $element['code'] }}">{{$element['text'] }}</td>
                    </tr>
                @endif
            @endforeach
        </table><!-- cart totals end -->
    </div><!-- cart total end -->
@endif

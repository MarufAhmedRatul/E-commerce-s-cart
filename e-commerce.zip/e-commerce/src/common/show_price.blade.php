<div class="product-price-wrap">
@switch($kind)
    @case(SC_PRODUCT_GROUP)
    <span class="amount">{!! trans('product.price_group') !!}</span>
        @break
    @default
        @if ($price == $priceFinal)
        <span class="amount">{!! sc_currency_render($price) !!}</span>
        @else
            <del>{!!  sc_currency_render($price) !!}</del>
        <span class="amount">{!! sc_currency_render($priceFinal) !!}</span>
        @endif
@endswitch
</div>     
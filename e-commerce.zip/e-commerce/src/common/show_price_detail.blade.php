
@switch($kind)
    @case(SC_PRODUCT_GROUP)
        <p class="regular-price">{!! trans('product.price_group_chose') !!}</p>
        @break
    @default
        @if ($price == $priceFinal)
            <p class="regular-price">{!! sc_currency_render($price) !!}</p>
        @else
            <p class="regular-price"><del>{!! sc_currency_render($priceFinal) !!}</del></p>
            <p class="sale-price">Sale: {!!  sc_currency_render($price) !!}</p>
        @endif
        @if (sc_config('product_display_price_include_tax'))
            ({!! trans('front.price_include_tax') !!})
        @else
            ({!! trans('front.price_without_tax') !!})
        @endif
@endswitch 
**Change made vendor s-cart folder

Location : Core/src/library/helpers/price.php
Old Code :

$html = $tmpAtt[0].'<span class="option_price">(+'.sc_currency_render($add_price,$currency, $rate).')</span>';

Replace Code :

$html = $tmpAtt[0].'<sup>(+'.sc_currency_render($add_price,$currency, $rate).')</sup>';

line No: 30


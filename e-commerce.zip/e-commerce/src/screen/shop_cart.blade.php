@php
/*
$layout_page = shop_cart
**Variables:**
- $cart: no paginate
- $shippingMethod: string
- $paymentMethod: string
- $totalMethod: array
- $dataTotal: array
- $shippingAddress: array
- $countries: array
- $attributesGroup: array
*/
@endphp 

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="box box-padding cart-page">

    <!--Notice -->
@include($sc_templatePath.'.common.notice')
<!--//Notice -->

    <div class="container">

        @if (count($cart) ==0)
        <div class="row">

            <div class="col-12">
                <div class="empty-cart">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"/></svg>
                    <p>{!! trans('cart.cart_empty') !!}!</p>
                </div><!-- empty cart end -->
                <a href="{{ sc_route('shop') }}" class="btn action-button">Return Shop</a>
            </div><!-- col end -->
        </div><!-- row end -->
        @else

            <div class="row">
                <div class="col-12">
                    <div class="cart-table">
                        <table class="table">
                            <thead>
                            <tr>
                                <th class="product-remove">&nbsp;</th>
                                <th class="product-sku">{{ trans('product.sku') }}</th>
                                <th class="product-name">{{ trans('product.name') }}</th>
                                <th class="product-price">{{ trans('product.price') }}</th>
                                <th class="product-quantity">{{ trans('product.quantity') }}</th>
                                <th class="product-subtotal">{{ trans('product.total_price') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($cart as $item)

                                @php
                                    $n = (isset($n)?$n:0);
                                    $n++;
                                    // Check product in cart
                                    $product = $modelProduct->start()->getDetail($item->id, null, $item->storeId);
                                    if(!$product) {
                                        continue;
                                    }
                                    // End check product in cart
                                @endphp

                            <tr class="cart-items {{ session('arrErrorQty')[$product->id] ?? '' }}{{ (session('arrErrorQty')[$product->id] ?? 0) ? ' has-error' : '' }}">
                                <td class="product-remove" >
                                    <a onClick="return confirm('Confirm?')" title="Remove Item" href="{{ sc_route("cart.remove",['id'=>$item->rowId]) }}" class="remove">×</a>
                                </td>
                                <td class="product-sku" data-title="{{ trans('product.sku') }}">{{ $product->sku }}</td>
                                <td class="product-name" data-title="{{ trans('product.name') }}">
                                    <a href="{{$product->getUrl() }}">
                                        <img src="{{asset($product->getImage())}}" alt="{{ $product->name }}">
                                    </a>
                                    <h2 class="product-title">
                                        <a href="{{$product->getUrl() }}">
                                            {{ $product->name }},

                                            @if ($item->options->count())
                                                @foreach ($item->options as $groupAtt => $att)
                                                    {!! sc_render_option_price($att) !!},
                                                @endforeach
                                            @endif
                                        </a>
                                    </h2>
                                </td>
                                <td class="product-price" data-title="{{ trans('product.price') }}">{!! $product->showPrice() !!}</td>
                                <td class="product-quantity" data-title="{{ trans('product.quantity') }}">
                                    <input type="number" min="1" data-id="{{ $item->id }}" name="qty-{{$item->id}}"  data-rowid="{{$item->rowId}}" data-store_id="{{$product->store_id}}" onChange="updateCart($(this));" class="form-control input-text item-qty" value="{{$item->qty}}" step="1">
                                    <div class="input-grp-btn">
                                        <span class="value-button increase">+</span>
                                        <span class="value-button decrease">-</span>
                                    </div><!-- input grp btn end -->

                                    @if (session('arrErrorQty')[$product->id] ?? 0)
                                        <span class="help-block">
                                        <br>{{ trans('cart.minimum_value', ['value' => session('arrErrorQty')[$product->id]]) }}
                                    </span>
                                    @endif
                                </td>
                                <td class="product-subtotal" data-title="{{ trans('product.total_price') }}">{{sc_currency_render($item->subtotal)}}</td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table><!-- table end -->
                    </div><!-- cart table end -->
                </div><!-- col end -->
            </div><!-- row end -->

            <div class="button-area">
                <div class="row">
                    <div class="col-6 text-left">
                        <button class="btn action-button" type="button" onClick="location.href='{{ sc_route('home') }}'">{{ trans('cart.back_to_shop') }}</button>
                    </div><!-- col end -->
                    <div class="col-6 text-right">
                        <button class="btn action-button" type="button" onClick="if(confirm('Confirm ?')) window.location.href='{{ sc_route('cart.clear') }}';"> {{ trans('cart.remove_all') }}</button>
                    </div><!-- col end -->
                </div><!-- row end -->
            </div><!-- button area end -->

            <div class="cart-bottom">
                <form class="sc-shipping-address" id="form-process" role="form" method="POST" action="{{ sc_route('cart.process') }}">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="customer-details">
                                <h3 class="title">Billing Details</h3>

                                <div class="billing-form">

                                    {{-- Select address if customer login --}}
                                    @if (auth()->user())
                                        <div class="form-group">
                                            <select class="form-control" name="address_process" style="width: 100%;" id="addressList">
                                                <option value="">{{ trans('cart.change_address') }}</option>
                                                @foreach ($addressList as $k => $address)
                                                    <option value="{{ $address->id }}" {{ (old('address_process') ==  $address->id) ? 'selected':''}}>- {{ $address->first_name. ' '.$address->last_name.', '.$address->address1.' '.$address->address2 }}</option>
                                                @endforeach
                                                <option value="new" {{ (old('address_process') ==  'new') ? 'selected':''}}>{{ trans('cart.add_new_address') }}</option>
                                            </select>
                                        </div>
                                    @endif
                                    {{--// Select address if customer login --}}

                                    @if (sc_config('customer_lastname'))
                                    <div class="form-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
                                                <label>{{ trans('cart.first_name') }}</label>
                                                <input type="text" name="first_name" class="form-control" placeholder="{{ trans('cart.first_name') }}" value="{{old('first_name', $shippingAddress['first_name'])}}">

                                                @if($errors->has('first_name'))
                                                    <span class="help-block">{{ $errors->first('first_name') }}</span>
                                                @endif
                                            </div><!-- form group end -->

                                        </div><!-- col end -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group{{ $errors->has('last_name') ? ' has-error' : '' }}">
                                                <label>{{ trans('cart.last_name') }}</label>
                                                <input type="text" name="last_name" class="form-control" placeholder="{{ trans('cart.last_name') }}"  value="{{old('last_name',$shippingAddress['last_name'])}}" >

                                                @if($errors->has('last_name'))
                                                    <span class="help-block">{{ $errors->first('last_name') }}</span>
                                                @endif
                                            </div><!-- form group end -->
                                        </div><!-- col end -->
                                    </div><!-- form row end -->

                                    @else

                                        <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
                                            <label>{{ trans('cart.name') }}</label>
                                            <input type="text" name="first_name" class="form-control" placeholder="{{ trans('cart.name') }}" value="{{old('first_name',$shippingAddress['first_name'])}}" >

                                            @if($errors->has('first_name'))
                                                <span class="help-block">{{ $errors->first('first_name') }}</span>
                                            @endif
                                        </div><!-- form group end -->
                                    @endif


                                    @if (sc_config('customer_name_kana'))
                                    <div class="form-group{{ $errors->has('first_name_kana') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.first_name_kana') }}</label>
                                        <input type="text" name="first_name_kana" class="form-control" placeholder="{{ trans('cart.first_name_kana') }}"value="{{old('first_name_kana', $shippingAddress['first_name_kana'])}}">

                                        @if($errors->has('first_name_kana'))
                                            <span class="help-block">{{ $errors->first('first_name_kana') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    <div class="form-group{{ $errors->has('last_name_kana') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.last_name_kana') }}</label>
                                        <input type="text" name="last_name_kana" class="form-control" placeholder="{{ trans('cart.last_name_kana') }}" value="{{old('last_name_kana',$shippingAddress['last_name_kana'])}}">

                                        @if($errors->has('last_name_kana'))
                                            <span class="help-block">{{ $errors->first('last_name_kana') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    @endif

                                    @if (sc_config('customer_phone'))
                                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.email') }}</label>
                                        <input type="text" name="email" class="form-control" placeholder="{{ trans('cart.email') }}" value="{{old('email', $shippingAddress['email'])}}">

                                        @if($errors->has('email'))
                                            <span class="help-block">{{ $errors->first('email') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    <div class="form-group{{ $errors->has('phone') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.phone') }}</label>
                                        <input type="text" name="phone" class="form-control" placeholder="{{ trans('cart.phone') }}" value="{{old('phone',$shippingAddress['phone'])}}">

                                        @if($errors->has('phone'))
                                            <span class="help-block">{{ $errors->first('phone') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    @else
                                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                            <label>{{ trans('cart.email') }}</label>
                                            <input type="text" name="email" class="form-control" placeholder="{{ trans('cart.email') }}" value="{{old('email',$shippingAddress['email'])}}">

                                            @if($errors->has('email'))
                                                <span class="help-block">{{ $errors->first('email') }}</span>
                                            @endif
                                        </div><!-- form group end -->
                                    @endif

                                    @if (sc_config('customer_country'))
                                    <div class="form-group{{ $errors->has('country') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.country') }}</label>
                                        @php
                                            $ct = old('country',$shippingAddress['country']);
                                        @endphp
                                        <select name="country" class="form-control" >
                                            <option value="">__{{ trans('cart.country') }}__</option>
                                            @foreach ($countries as $k => $v)
                                                <option value="{{ $k }}" {{ ($ct ==$k) ? 'selected':'' }}>{{ $v }}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('country'))
                                            <span class="help-block">
                                                {{ $errors->first('country') }}
                                            </span>
                                        @endif
                                    </div><!-- form group end -->
                                    @endif

                                    @if (sc_config('customer_postcode'))
                                    <div class="form-group {{ $errors->has('postcode') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.postcode') }}</label>
                                        <input type="text" name="postcode" class="form-control" placeholder="{{ trans('cart.postcode') }}" value="{{ old('postcode',$shippingAddress['postcode'])}}">

                                        @if($errors->has('postcode'))
                                            <span class="help-block">{{ $errors->first('postcode') }}</span>
                                        @endif
                                    </div><!-- form group end -->
                                    @endif

                                    @if (sc_config('customer_company'))
                                    <div class="form-group {{ $errors->has('company') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.company') }}</label>
                                        <input type="text" name="company" class="form-control" placeholder="{{ trans('cart.company') }}" value="{{ old('company',$shippingAddress['company'])}}">

                                        @if($errors->has('postcode'))
                                            <span class="help-block">{{ $errors->first('postcode') }}</span>
                                        @endif
                                    </div><!-- form group end -->
                                    @endif

                                    @if (sc_config('customer_address2'))
                                    <div class="form-group {{ $errors->has('address1') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.address1') }}</label>
                                        <input type="text" name="address1" class="form-control" placeholder="{{ trans('cart.address1') }}" value="{{ old('address1',$shippingAddress['address1'])}}">

                                        @if($errors->has('address1'))
                                            <span class="help-block">{{ $errors->first('address1') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    <div class="form-group {{ $errors->has('address2') ? ' has-error' : '' }}">
                                        <label>{{ trans('cart.address2') }}</label>
                                        <input type="text" name="address2" class="form-control" placeholder="{{ trans('cart.address2') }}" value="{{ old('address2',$shippingAddress['address2'])}}">

                                        @if($errors->has('address2'))
                                            <span class="help-block">{{ $errors->first('address2') }}</span>
                                        @endif
                                    </div><!-- form group end -->

                                    @else
                                        @if (sc_config('customer_address1'))
                                            <div class="form-group {{ $errors->has('address1') ? ' has-error' : '' }}">
                                                <label>{{ trans('cart.address') }}</label>
                                                <input type="text" name="address1" class="form-control" placeholder="{{ trans('cart.address') }}" value="{{ old('address1',$shippingAddress['address1'])}}">

                                                @if($errors->has('address1'))
                                                    <span class="help-block">{{ $errors->first('address1') }}</span>
                                                @endif
                                            </div><!-- form group end -->
                                        @endif

                                    @endif

                                    <div class="form-group">
                                        <label>{{ trans('cart.note') }}</label>

                                        <textarea name="comment" class="form-control" placeholder="{{ trans('cart.note') }}....">{{ old('comment','')}}</textarea>
                                    </div><!-- form group end -->

                                </div><!-- billing form end -->
                            </div><!-- customer details end -->
                        </div><!-- col end -->
                        <div class="col-md-6 col-sm-12">
                            {{-- Data total --}}
                            @if (view()->exists($sc_templatePath.'.common.render_total'))
                                @include($sc_templatePath.'.common.render_total')
                            @endif
                            {{-- Data total --}}

                            {{-- Total method --}}
                            <div class="form-group {{ $errors->has('totalMethod') ? ' has-error' : '' }}">
                                @if($errors->has('totalMethod'))
                                    <span class="help-block">{{ $errors->first('totalMethod') }}</span>
                                @endif
                            </div>


                                @foreach ($totalMethod as $key => $plugin)
                                    @if (view()->exists($plugin['pathPlugin'].'::render'))
                                    <div class="form-group">
                                        @include($plugin['pathPlugin'].'::render')
                                    </div>
                                    @endif
                                @endforeach

                            {{-- //Total method --}}

                            <div class="payment-option">
                                @if (!sc_config('shipping_off'))
                                    {{-- Shipping method --}}
                                    <div class="form-group {{ $errors->has('shippingMethod') ? ' has-error' : '' }}">
                                        <h6 class="control-label">{{ trans('cart.shipping_method') }}</h6>
                                        @if($errors->has('shippingMethod'))
                                            <span class="help-block">{{ $errors->first('shippingMethod') }}</span>
                                        @endif

                                        @foreach ($shippingMethod as $key => $shipping)
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="shippingMethod" value="{{ $shipping['key'] }}" {{ (old('shippingMethod') == $key)?'checked':'' }} {{ ($shipping['permission'])?'':'disabled' }}>
                                                <label class="form-check-label">{{ $shipping['title'] }}</label>
                                                ({{ sc_currency_render($shipping['value']) }})
                                            </div>
                                        @endforeach
                                    </div>

                                    {{-- //Shipping method --}}
                                @endif


                                @if (!sc_config('payment_off'))
                                    {{-- Payment method --}}

                                    <div class="form-group {{ $errors->has('paymentMethod') ? ' has-error' : '' }}">
                                        <h6 class="control-label">{{ trans('cart.payment_method') }}</h6>
                                        @if($errors->has('paymentMethod'))
                                            <span class="help-block">{{ $errors->first('paymentMethod') }}</span>
                                        @endif


                                        @foreach ($paymentMethod as $key => $payment)
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="paymentMethod" value="{{ $payment['key'] }}" {{ (old('shippingMethod') == $key)?'checked':'' }} {{ ($payment['permission'])?'':'disabled' }}>
                                                <label class="form-check-label">{{ $payment['title'] }}</label>
                                            </div>
                                        @endforeach
                                    </div>

                                    {{-- //Payment method --}}
                                @endif


                                {{-- Button checkout --}}
                                <div class="text-center">
                                    {!! $viewCaptcha ?? ''!!}
                                </div>
                            </div><!-- payment option end -->

                            <div class="text-right">
                                <button class="btn action-button checkout-button" id="button-form-process" type="submit">{{ trans('cart.checkout') }}</button>
                            </div>
                            {{-- Button checkout --}}

                        </div><!-- col end -->
                    </div><!-- row end -->


                </form><!-- form end -->
            </div><!-- cart bottom end -->

        @endif
    </div><!-- container end -->
</section>
@endsection


{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
  </div><!-- box end -->
@endsection
{{-- //breadcrumb --}}


@push('scripts')

<script type="text/javascript">
    @foreach ($totalMethod as $key => $plugin)
        @if (view()->exists($plugin['pathPlugin'].'::script'))
            @include($plugin['pathPlugin'].'::script')
        @endif
    @endforeach

    function updateCart(obj){
        let new_qty = obj.val();
        let storeId = obj.data('store_id');
        let rowid = obj.data('rowid');
        let id = obj.data('id');
        $.ajax({
            url: '{{ sc_route('cart.update') }}',
            type: 'POST',
            dataType: 'json',
            async: false,
            cache: false,
            data: {
                id: id,
                rowId: rowid,
                new_qty: new_qty,
                storeId: storeId,
                _token:'{{ csrf_token() }}'},
            success: function(data){
                error= parseInt(data.error);
                if(error ===0)
                {
                    window.location.replace(location.href);
                }else{
                    $('.item-qty-'+id).css('display','block').html(data.msg);
                }

                }
        });
    }

    $(document).on('click', '.product-quantity .input-grp-btn .value-button', function() {
        var $input = $(this).closest('.product-quantity').find('.input-text');

        if ($(this).hasClass('increase')) {
            $input.trigger('stepUp').trigger('change');
        }

        if ($(this).hasClass('decrease')) {
            $input.trigger('stepDown').trigger('change');
        }
    });


    $('#button-form-process').click(function(){
        $('#form-process').submit();
        $(this).prop('disabled',true);
    });

    $('#addressList').change(function(){
        var id = $('#addressList').val();
        if(!id) {
            return;
        } else if(id == 'new') {
            $('#form-process [name="first_name"]').val('');
            $('#form-process [name="last_name"]').val('');
            $('#form-process [name="phone"]').val('');
            $('#form-process [name="postcode"]').val('');
            $('#form-process [name="company"]').val('');
            $('#form-process [name="country"]').val('');
            $('#form-process [name="address1"]').val('');
            $('#form-process [name="address2"]').val('');
        } else {
            $.ajax({
                url: '{{ sc_route('customer.address_detail') }}',
                type: 'POST',
                dataType: 'json',
                async: false,
                cache: false,
                data: {
                    id: id,
                    _token:'{{ csrf_token() }}'},
                success: function(data){
                    error= parseInt(data.error);
                    if(error === 1)
                    {
                        alert(data.msg);
                    }else{
                        $('#form-process [name="first_name"]').val(data.first_name);
                        $('#form-process [name="last_name"]').val(data.last_name);
                        $('#form-process [name="phone"]').val(data.phone);
                        $('#form-process [name="postcode"]').val(data.postcode);
                        $('#form-process [name="company"]').val(data.company);
                        $('#form-process [name="country"]').val(data.country);
                        $('#form-process [name="address1"]').val(data.address1);
                        $('#form-process [name="address2"]').val(data.address2);
                    }

                }
            });
        }
    });

</script>
@endpush

@push('styles')
{{-- Your css style --}}
@endpush
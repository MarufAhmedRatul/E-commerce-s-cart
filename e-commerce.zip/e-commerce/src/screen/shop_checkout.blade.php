@php
/*
$layout_page = shop_cart
**Variables:**
- $cart: no paginate
- $shippingMethod: string
- $paymentMethod: string
- $dataTotal: array
- $shippingAddress: array
- $attributesGroup: array
- $products: paginate
Use paginate: $products->appends(request()->except(['page','_token']))->links()
*/
@endphp 

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="box box-padding checkout">
    <div class="container">
        @if (count($cart) ==0)
            <div class="row">

                <div class="col-12">
                    <div class="empty-cart">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"/></svg>
                        <p>{!! trans('cart.cart_empty') !!}</p>
                    </div><!-- empty cart end -->
                    <a href="{{ sc_route('shop') }}" class="btn action-button">Return Shop</a>
                </div><!-- col end -->
            </div><!-- row end -->
        @else

            <div class="row">
                <div class="col-12">
                    <div class="cart-table">
                        <table class="table">
                            <thead>
                            <tr>
                                <th class="product-sku">{{ trans('product.sku') }}</th>
                                <th class="product-name">{{ trans('product.name') }}</th>
                                <th class="product-price">{{ trans('product.price') }}</th>
                                <th class="product-quantity">{{ trans('product.quantity') }}</th>
                                <th class="product-subtotal">{{ trans('product.total_price') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($cart as $item)
                                @php
                                    $product = $modelProduct->start()->getDetail($item->id, null, $item->storeId);
                                @endphp
                                <tr class="cart-items">

                                    <td class="product-sku" data-title="{{ trans('product.sku') }}">{{ $product->sku }}</td>
                                    <td class="product-name" data-title="{{ trans('product.name') }}">
                                        <a href="{{$product->getUrl() }}">
                                            <img src="{{asset($product->getImage())}}" alt="{{ $product->name }}">
                                        </a>
                                        <h2 class="product-title">
                                            {{ $product->name }},

                                            @if ($item->options->count())
                                                @foreach ($item->options as $keyAtt => $att)
                                                    {!! sc_render_option_price($att) !!},
                                                @endforeach
                                            @endif
                                        </h2>
                                    </td>
                                    <td class="product-price" data-title="{{ trans('product.price') }}">{!! $product->showPrice() !!}</td>
                                    <td class="product-quantity" data-title="{{ trans('product.quantity') }}">
                                        {{$item->qty}}
                                    </td>
                                    <td class="product-subtotal" data-title="{{ trans('product.total_price') }}">{{sc_currency_render($item->subtotal)}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table><!-- table end -->
                    </div><!-- cart table end -->
                </div><!-- col end -->
            </div><!-- row end -->

            <div class="cart-bottom">
                <form class="sc-shipping-address" id="form-order" role="form" method="POST" action="{{ sc_route('order.add') }}">
                    {{-- Required csrf for secirity --}}
                    @csrf
                    {{--// Required csrf for secirity --}}

                    <div class="row">
                        <div class="col-md-6 col-sm-12">

                            <div class="cart_totals">
                                <h3>{{ trans('cart.shipping_address') }}</h3>
                                <table class="table cart-totals" id="showTotal">
                                    <tr>
                                        <th>{{ trans('cart.name') }}:</td>
                                        <td>{{ $shippingAddress['first_name'] }} {{ $shippingAddress['last_name'] }}</td>
                                    </tr>
                                    @if (sc_config('customer_name_kana'))
                                        <tr>
                                            <th>{{ trans('cart.name_kana') }}:</td>
                                            <td>{{ $shippingAddress['first_name_kana'].$shippingAddress['last_name_kana'] }}</td>
                                        </tr>
                                    @endif

                                    @if (sc_config('customer_phone'))
                                        <tr>
                                            <th>{{ trans('cart.phone') }}:</td>
                                            <td>{{ $shippingAddress['phone'] }}</td>
                                        </tr>
                                    @endif
                                    <tr>
                                        <th>{{ trans('cart.email') }}:</td>
                                        <td>{{ $shippingAddress['email'] }}</td>
                                    </tr>
                                    <tr>
                                        <th>{{ trans('cart.address') }}:</td>
                                        <td>{{ $shippingAddress['address1'].' '.$shippingAddress['address2'].','.$shippingAddress['country'] }}
                                        </td>
                                    </tr>
                                    @if (sc_config('customer_postcode'))
                                        <tr>
                                            <th>{{ trans('cart.postcode') }}:</td>
                                            <td>{{ $shippingAddress['postcode']}}</td>
                                        </tr>
                                    @endif

                                    @if (sc_config('customer_company'))
                                        <tr>
                                            <th>{{ trans('cart.company') }}:</td>
                                            <td>{{ $shippingAddress['company']}}</td>
                                        </tr>
                                    @endif

                                    <tr>
                                        <th>{{ trans('cart.note') }}:</td>
                                        <td>{{ $shippingAddress['comment'] }}</td>
                                    </tr>
                                </table><!-- cart totals end -->
                            </div><!-- cart total end -->

                        </div><!-- col end -->

                        <div class="col-md-6 col-sm-12">
                            <div class="cart_totals">
                                <h3>Cart Totals</h3>
                                <table class="table cart-totals" id="showTotal">
                                    @foreach ($dataTotal as $key => $element)
                                        @if ($element['code']=='total')
                                    <tr class="cart-subtotal">
                                        <th>{!! $element['title'] !!}</th>
                                        <td id="{{ $element['code'] }}">{{$element['text'] }}</td>
                                    </tr>
                                        @elseif($element['value'] !=0)
                                            <tr class="cart-subtotal">
                                                <th>{!! $element['title'] !!}</th>
                                                <td id="{{ $element['code'] }}">{{$element['text'] }}</td>
                                            </tr>
                                        @elseif($element['code'] =='shipping')
                                            <tr class="cart-subtotal">
                                                <th>{!! $element['title'] !!}</th>
                                                <td id="{{ $element['code'] }}">{{$element['text'] }}</td>
                                            </tr>
                                        @endif
                                    @endforeach
                                </table><!-- cart totals end -->
                            </div><!-- cart total end -->


                            @if (!sc_config('payment_off'))
                            <div class="form-group">
                                <h3 class="control-label">{{ trans('cart.payment_method') }}</h3>
                                <p>{{ $paymentMethodData['title'] }}</p>
                            </div><!-- form group end -->
                            @endif

                            <div class="button-area">
                                <div class="row">
                                    <div class="col-6 text-left">
                                        <button class="btn action-button" type="button" onClick="location.href='{{ sc_route('cart') }}'">{{ trans('cart.back_to_cart') }}</button>
                                    </div><!-- col end -->
                                    <div class="col-6 text-right">
                                        <button class="btn action-button" type="submit" id="submit-order"> {{ trans('cart.confirm') }}</button>
                                    </div><!-- col end -->
                                </div><!-- row end -->
                            </div><!-- button area end -->
                        </div><!-- col end -->
                    </div><!-- row end -->
                </form><!-- form end -->
            </div><!-- cart bottom end -->

        @endif
    </div>
</section>
@endsection

{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
  </div><!-- box end -->
@endsection
{{-- //breadcrumb --}}



@push('scripts')
{{-- Your scripts --}}
@endpush

@push('styles')
{{-- Your css style --}}
@endpush
@php
/*
$layout_page = shop_compare
**Variables:**
- $compare: no paginate
*/
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main_content_center')
<div class="col-lg-8 col-xl-9">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h6 class="aside-title">{{ $title }}</h6>
            </div>
            @if (count($compare) ==0)
                <div class="col-md-12 text-danger min-height-37vh">
                    {{ trans('front.no_data') }}
                </div>
            @else
 
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table box table-bordered">
                        <tbody>
                            <tr>
                                @php
                                    $n = 0;
                                @endphp

                                @foreach($compare as $key => $item)
                                        @php
                                            $n++;
                                            $product = $modelProduct->start()->getDetail($item->id, null, $item->storeId);
                                        @endphp
                                        <td align="center">
                                            {{ $product->name }}({{ $product->sku }})
                                            <hr>
                                            <a href="{{ $product->getUrl() }}"><img width="100"
                                                    src="{{asset($product->getImage())}}" alt=""></a>
                                            <hr>
                                            {!! $product->showPrice() !!}
                                            <hr>
                                            {!! $product->description !!}
                                            <hr>
                                            <a onClick="return confirm('Confirm')" title="Remove Item" alt="Remove Item"
                                                class="cart_quantity_delete"
                                                href="{{ sc_route("compare.remove",['id'=>$item->rowId]) }}"><i
                                                    class="fa fa-times"></i></a>
                                        </td>
                                        @if ($n % 4 == 0)
                                        </tr>
                                        @endif
                                @endforeach
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            @endif
            
        </div>
    </div>
</div>
@endsection

{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
  </div><!-- box end -->
@endsection
{{-- //breadcrumb --}}

@push('scripts')
{{-- Your scripts --}}
@endpush

@push('styles')
{{-- Your css style --}}
@endpush
@php
/*
$layout_page = item_list
**Variables:**
- $itemsList: paginate
Use paginate: $itemsList->appends(request()->except(['page','_token']))->links()
*/
@endphp
 
@extends($sc_templatePath.'.layout')

@section('block_main_content_center')
<div class="col-md-9 col-sm-12">
<h6 class="aside-title">{{ $title }}</h6>
<section class="product-display">
    <div class="row">
        @if ($itemsList->count())
            @foreach ($itemsList as $item)
                <div class="col-md-3 col-sm-12">
                    <!-- Post Classic-->
                    <div class="item">
                        <div class="thumb-wrap">
                            <div class="thumb">
                                <a href="{{ $item->getUrl() }}" title="product">
                                    <img src="{{ asset($item->getThumb()) }}" alt="{{ $item->name }}">
                                </a>
                            </div><!-- thumb end -->
                        </div><!-- thumb wrap end -->
                        <div class="title-area">
                            <h4 class="title">
                                <a href="{{ $item->getUrl() }}">{{ $item->name }}</a>
                            </h4>
                        </div><!-- title area end -->
                    </div>
                </div>
            @endforeach

            <div class="pagination-wrap">
                <!-- Bootstrap Pagination-->
                {{ $itemsList->links() }}
            </div>
        @else
            {!! trans('front.no_data') !!}
        @endif
    </div>
  </section>
</div>
@endsection


{{-- breadcrumb --}}
@section('breadcrumb')
@php
//$bannerBreadcrumb = $modelBanner->start()->getBreadcrumb()->getData()->first();
@endphp
<div class="box">
  <div class="pager-banner">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <div class="banner-content">
                      <h1>{{ $title ?? '' }}</h1>
                      <div class="page-breadcrumb">
                          <ul>
                              <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                              <li><span>{{ $title ?? '' }}</span></li>
                          </ul>
                      </div><!-- page breadcrumb end -->
                  </div><!-- banne content end -->
              </div><!-- col end -->
          </div><!-- row end -->
      </div><!-- container end -->
  </div><!-- page banner end -->
</div><!-- box end -->
@endsection
{{-- //breadcrumb --}}


@section('filter')
<form action="" method="GET" id="filter_sort">
    <div class="pull-right">
        <div>
            @php
            $queries = request()->except(['filter_sort','page']);
            @endphp
            @foreach ($queries as $key => $query)
            <input type="hidden" name="{{ $key }}" value="{{ $query }}">
            @endforeach
            <select class="custom-select" name="filter_sort">
                <option value="">{{ trans('front.filters.sort') }}</option>
                <option value="name_asc" {{ ($filter_sort =='name_asc')?'selected':'' }}>
                    {{ trans('front.filters.name_asc') }}</option>
                <option value="name_desc" {{ ($filter_sort =='name_desc')?'selected':'' }}>
                    {{ trans('front.filters.name_desc') }}</option>
                <option value="sort_asc" {{ ($filter_sort =='sort_asc')?'selected':'' }}>
                    {{ trans('front.filters.sort_asc') }}</option>
                <option value="sort_desc" {{ ($filter_sort =='sort_desc')?'selected':'' }}>
                    {{ trans('front.filters.sort_desc') }}</option>
                <option value="id_asc" {{ ($filter_sort =='id_asc')?'selected':'' }}>{{ trans('front.filters.id_asc') }}
                </option>
                <option value="id_desc" {{ ($filter_sort =='id_desc')?'selected':'' }}>
                    {{ trans('front.filters.id_desc') }}</option>
            </select>
        </div>
    </div>
</form>

@endsection

@push('scripts')
<script type="text/javascript">
    $('[name="filter_sort"]').change(function(event) {
      $('#filter_sort').submit();
    });
</script>
@endpush

@push('styles')
{{-- Your css style --}}
@endpush
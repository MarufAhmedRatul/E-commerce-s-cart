@php
/*
$layout_page = product_detail
**Variables:**
- $product: no paginate
- $productRelation: no paginate
*/
@endphp

@extends($sc_templatePath.'.layout')

{{-- block_main --}}
@section('block_main')
@php
    $countItem = 0
@endphp

<div class="box box-padding single-product">
    <div class="container"> 
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="product-images-area">
                    <div class="product-display">
                        <div class="owl-carousel owl-theme">

                            <div class="item">
                                <div class="thumb-wrap">
                                    <div class="thumb">
                                        <img src="{{ asset($product->getImage()) }}" alt="product">
                                    </div><!-- thumb end -->
                                    @if ($product->price != $product->getFinalPrice())
                                        <span class="onsale">Sale</span>
                                    @endif
                                </div><!-- thumb wrap end -->
                            </div><!-- item -->

                            @php
                                $countItem = 1 + $product->images->count();
                            @endphp
                            @if ($countItem > 1)
                                @foreach ($product->images as $key=>$image)
                            <div class="item">
                                <div class="thumb-wrap">
                                    <div class="thumb">
                                        <img src="{{ asset($image->getImage()) }}" alt="product">
                                    </div><!-- thumb end -->
                                    @if ($product->price != $product->getFinalPrice())
                                        <span class="onsale">Sale</span>
                                    @endif
                                </div><!-- thumb wrap end -->
                            </div><!-- item -->

                                @endforeach
                            @endif
                        </div><!-- owl caraousel end -->
                    </div><!-- product display end -->
                </div><!-- product images end -->
            </div><!-- col end -->

            <div class="col-md-7 col-sm-12">
                <form id="buy_block" action="{{ sc_route('cart.add') }}" method="post">
                    {{ csrf_field() }}

                    <input type="hidden" name="product_id" id="product-detail-id" value="{{ $product->id }}" />

                    <input type="hidden" name="storeId" id="product-detail-storeId" value="{{ $product->store_id }}" />

                <div class="product-details">
                    <div class="detail-head">
                        <h2 class="title">{{ $product->name }}</h2>
                        <a onClick="addToCartAjax('{{ $product->id }}','wishlist','{{ $product->store_id }}')" rel="nofollow" title="Add to Wishlist">
                            <svg class="fev-button" viewBox="0 -28 512.001 512" xmlns="http://www.w3.org/2000/svg">
                                <path d="m256 455.515625c-7.289062 0-14.316406-2.640625-19.792969-7.4375-20.683593-18.085937-40.625-35.082031-58.21875-50.074219l-.089843-.078125c-51.582032-43.957031-96.125-81.917969-127.117188-119.3125-34.644531-41.804687-50.78125-81.441406-50.78125-124.742187 0-42.070313 14.425781-80.882813 40.617188-109.292969 26.503906-28.746094 62.871093-44.578125 102.414062-44.578125 29.554688 0 56.621094 9.34375 80.445312 27.769531 12.023438 9.300781 22.921876 20.683594 32.523438 33.960938 9.605469-13.277344 20.5-24.660157 32.527344-33.960938 23.824218-18.425781 50.890625-27.769531 80.445312-27.769531 39.539063 0 75.910156 15.832031 102.414063 44.578125 26.191406 28.410156 40.613281 67.222656 40.613281 109.292969 0 43.300781-16.132812 82.9375-50.777344 124.738281-30.992187 37.398437-75.53125 75.355469-127.105468 119.308594-17.625 15.015625-37.597657 32.039062-58.328126 50.167969-5.472656 4.789062-12.503906 7.429687-19.789062 7.429687zm-112.96875-425.523437c-31.066406 0-59.605469 12.398437-80.367188 34.914062-21.070312 22.855469-32.675781 54.449219-32.675781 88.964844 0 36.417968 13.535157 68.988281 43.882813 105.605468 29.332031 35.394532 72.960937 72.574219 123.476562 115.625l.09375.078126c17.660156 15.050781 37.679688 32.113281 58.515625 50.332031 20.960938-18.253907 41.011719-35.34375 58.707031-50.417969 50.511719-43.050781 94.136719-80.222656 123.46875-115.617188 30.34375-36.617187 43.878907-69.1875 43.878907-105.605468 0-34.515625-11.605469-66.109375-32.675781-88.964844-20.757813-22.515625-49.300782-34.914062-80.363282-34.914062-22.757812 0-43.652344 7.234374-62.101562 21.5-16.441406 12.71875-27.894532 28.796874-34.609375 40.046874-3.453125 5.785157-9.53125 9.238282-16.261719 9.238282s-12.808594-3.453125-16.261719-9.238282c-6.710937-11.25-18.164062-27.328124-34.609375-40.046874-18.449218-14.265626-39.34375-21.5-62.097656-21.5zm0 0"/>
                            </svg>
                        </a>
                    </div><!-- detail head end -->
                    <div class="price">
                        {!! $product->showPriceDetail() !!}
                    </div><!-- price -->
                    <div class="product_meta-area">
                        <div class="product-meta-group">
                            <ul>
                                <li><span>SKU :</span> {{ $product->sku }}</li>
                                <li class="meta-seperator"></li>
                                @if (sc_config('product_stock'))
                                <li><span>{{ trans('product.stock_status') }} :</span>
                                    @if($product->stock <=0 && !sc_config('product_buy_out_of_stock'))
                                        {{ trans('product.out_stock') }}
                                    @else
                                        {{ trans('product.in_stock') }}
                                    @endif
                                </li>
                                @endif
                            </ul>
                        </div><!-- product meta group -->
                        <div class="product-meta-term">
                            <ul>
                                <li><span>Category :</span>
                                    @foreach ($product->categories as $category)
                                    <a href="{{ $category->getUrl() }}" >{{ $category->getTitle() }}</a>
                                    @endforeach
                                </li>
                                <li class="meta-seperator"></li>
                                @if (sc_config('product_brand') && !empty($product->brand->name))
                                <li><span>Brand :</span> {!! empty($product->brand->name) ? 'None' : '<a href="'.$product->brand->getUrl().'">'.$product->brand->name.'</a>' !!}</li>
                                @endif
                            </ul>
                        </div>
                    </div><!-- product meta area end -->
                    @if (sc_config('product_property'))
                    <div class="short-description">
                        {!! sc_html_render($product->content) !!}
                    </div><!-- description end -->
                    @endif
                    <div class="variations">
                        <table class="table">
                            <tr>
                                <th>Quantity</th>
                                <td>:</td>
                                <td class="quantity">
                                    <input type="number" name="qty" min="1" data-zeros="true" class="form-control input-text" value="1" step="1" size="4">
                                    <div class="input-grp-btn">
                                        <span class="value-button increase">+</span>
                                        <span class="value-button decrease">-</span>
                                    </div><!-- input grp btn end -->
                                </td>
                            </tr>
                            @if (sc_config('product_available') && $product->date_available >= date('Y-m-d H:i:s'))
                            <tr>
                                <th>{{ trans('product.date_available') }}</th>
                                <td>:</td>
                                <td>{{ $product->date_available }}</td>
                            </tr>
                            @endif

                            @if ($product->attributes())
                                {!! $product->renderAttributeDetails() !!}
                            @endif
                        </table><!-- table end -->
                    </div><!-- variations end -->


                    {{-- Product kind --}}
                    @if ($product->kind == SC_PRODUCT_GROUP)
                        <div class="products-group">
                            @php
                                $groups = $product->groups
                            @endphp
                            <h6>{{ trans('product.groups') }}</h6>
                            @foreach ($groups as $group)                                
                            <a target=_blank href="{{ $group->product->getUrl() }}">
                                {!! sc_image_render($group->product->image) !!}
                            </a>
                            @endforeach
                        </div>
                    @endif


                    @if ($product->kind == SC_PRODUCT_BUILD)
                        <div class="products-group">
                            @php
                                $builds = $product->builds
                            @endphp
                            <h6>{{ trans('product.builds') }}</h6>
                            <span class="sc-product-build">
                          {!! sc_image_render($product->image) !!} =
                      </span>
                            @foreach ($builds as $k => $build)
                                {!! ($k) ? '<i class="fa fa-plus" aria-hidden="true"></i>':'' !!}
                                <span class="sc-product-build">{{ $build->quantity }} x
                          <a target="_new" href="{{ $build->product->getUrl() }}">{!!
                              sc_image_render($build->product->image) !!}</a>
                      </span>
                            @endforeach
                        </div>
                    @endif
                    {{-- Product kind --}}

                    

                    <div class="single-cart-area text-right">
                        @if ($product->allowSale())
                        <button type="submit" class="btn action-button">{{ trans('front.add_to_cart') }}</button>
                        @endif
                    </div><!-- single cart area end -->
                </div><!-- product details end -->
                </form>
            </div><!-- col end -->
        </div><!-- row end -->

        <div class="row">
            <div class="col-12">
                <div class="product-full-details">
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">{{ trans('product.description') }}</a>

                    </div><!-- nav tabs end -->

                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            {!! sc_html_render($product->content) !!}
                        </div>

                    </div><!-- tab content end -->
                </div><!-- product full details end -->
            </div><!-- col end -->
        </div><!-- row end -->
    </div><!-- container end -->
</div><!-- box end -->

@if ($productRelation->count())
<div class="box you-may-like">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h4 class="title">Related Products</h4>
                </div><!-- section title end -->
            </div><!-- col end -->
        </div><!-- row end -->
        <div class="product-display">
            <div class="row">
                @foreach ($productRelation as $key => $product_rel)
                <div class="col-md-3 col-sm-6">
                    <div class="item">
                        <div class="thumb-wrap">
                            <div class="thumb">
                                <a href="{{ $product_rel->getUrl() }}" title="product">
                                    <img src="{{ asset($product_rel->getThumb()) }}" alt="{{ $product_rel->name }}">
                                </a>
                            </div><!-- thumb end -->
                            @if ($product_rel->price != $product_rel->getFinalPrice())
                            <span class="onsale">Sale</span>
                            @endif
                        </div><!-- thumb wrap end -->
                        <div class="title-area">
                            <h4 class="title">
                                <a href="{{ $product_rel->getUrl() }}">{{ $product_rel->name }}</a>
                            </h4>
                        </div><!-- title area end -->
                        <div class="price-area">
                            <div class="price">
                                <span class="amount">
                                    {!! $product_rel->showPrice() !!}
                                </span>
                            </div><!-- price end -->
                        </div><!-- price area end -->
                        <div class="button-area">
                            <div class="buttons">
                                <a onClick="addToCartAjax('{{ $product_rel->id }}','wishlist','{{ $product_rel->store_id }}')" class="fev-button" rel="nofollow" title="Add to Wishlist" target="_blank">
                                    <svg viewBox="0 -28 512.001 512" xmlns="http://www.w3.org/2000/svg">
                                        <path d="m256 455.515625c-7.289062 0-14.316406-2.640625-19.792969-7.4375-20.683593-18.085937-40.625-35.082031-58.21875-50.074219l-.089843-.078125c-51.582032-43.957031-96.125-81.917969-127.117188-119.3125-34.644531-41.804687-50.78125-81.441406-50.78125-124.742187 0-42.070313 14.425781-80.882813 40.617188-109.292969 26.503906-28.746094 62.871093-44.578125 102.414062-44.578125 29.554688 0 56.621094 9.34375 80.445312 27.769531 12.023438 9.300781 22.921876 20.683594 32.523438 33.960938 9.605469-13.277344 20.5-24.660157 32.527344-33.960938 23.824218-18.425781 50.890625-27.769531 80.445312-27.769531 39.539063 0 75.910156 15.832031 102.414063 44.578125 26.191406 28.410156 40.613281 67.222656 40.613281 109.292969 0 43.300781-16.132812 82.9375-50.777344 124.738281-30.992187 37.398437-75.53125 75.355469-127.105468 119.308594-17.625 15.015625-37.597657 32.039062-58.328126 50.167969-5.472656 4.789062-12.503906 7.429687-19.789062 7.429687zm-112.96875-425.523437c-31.066406 0-59.605469 12.398437-80.367188 34.914062-21.070312 22.855469-32.675781 54.449219-32.675781 88.964844 0 36.417968 13.535157 68.988281 43.882813 105.605468 29.332031 35.394532 72.960937 72.574219 123.476562 115.625l.09375.078126c17.660156 15.050781 37.679688 32.113281 58.515625 50.332031 20.960938-18.253907 41.011719-35.34375 58.707031-50.417969 50.511719-43.050781 94.136719-80.222656 123.46875-115.617188 30.34375-36.617187 43.878907-69.1875 43.878907-105.605468 0-34.515625-11.605469-66.109375-32.675781-88.964844-20.757813-22.515625-49.300782-34.914062-80.363282-34.914062-22.757812 0-43.652344 7.234374-62.101562 21.5-16.441406 12.71875-27.894532 28.796874-34.609375 40.046874-3.453125 5.785157-9.53125 9.238282-16.261719 9.238282s-12.808594-3.453125-16.261719-9.238282c-6.710937-11.25-18.164062-27.328124-34.609375-40.046874-18.449218-14.265626-39.34375-21.5-62.097656-21.5zm0 0"/>
                                    </svg>
                                </a>
                                @if ($product_rel->allowSale())
                                <a onClick="addToCartAjax('{{ $product_rel->id }}','default','{{ $product_rel->store_id }}')" class="cart-button add-to-cart-list" rel="nofollow" title="Add to cart">{{trans('front.add_to_cart')}}</a>
                                    @endif
                            </div><!-- buttons end -->
                        </div><!-- button area end -->
                    </div><!-- item -->
                </div><!-- col end -->
                @endforeach
            </div><!-- row end -->
        </div><!-- product display end -->
    </div><!-- container end -->
</div><!-- box end -->
@endif

<!--/product-details-->
@endsection
{{-- block_main --}}


{{-- breadcrumb --}}
@section('breadcrumb')
@php
//$bannerBreadcrumb = $modelBanner->start()->getBreadcrumb()->getData()->first();
@endphp
<div class="box">
  <div class="pager-banner">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <div class="banner-content">
                      <h1>{{ trans('front.product_detail') }}</h1>
                      <div class="page-breadcrumb">
                          <ul>
                              <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                              {{-- Display store info if use MultiStorePro --}}
                              @if (sc_config_global('MultiStorePro') && config('app.storeId') == SC_ID_ROOT)
                                  <li><a href="{{ $goToStore }}">{{ sc_store('title', $product->store_id) }}</a></li>
                              @endif
                              {{--// Display store info if use MultiStorePro --}}
                              <li><span>{{ $title ?? '' }}</span></li>
                          </ul>
                      </div><!-- page breadcrumb end -->
                  </div><!-- banne content end -->
              </div><!-- col end -->
          </div><!-- row end -->
      </div><!-- container end -->
  </div><!-- page banner end -->
</div><!-- box end -->
@endsection
{{-- //breadcrumb --}}


@push('styles')
{{-- Your css style --}}
@endpush

@push('scripts')


<script>
    //owl carousel
    $('.owl-carousel').owlCarousel({
        autoplay: false,
        items: 1,
        margin: 0,
        nav: true,
        dots:false,
        loop:true,
        navText : ["<svg version='1.1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'><path d='M14 20c0.128 0 0.256-0.049 0.354-0.146 0.195-0.195 0.195-0.512 0-0.707l-8.646-8.646 8.646-8.646c0.195-0.195 0.195-0.512 0-0.707s-0.512-0.195-0.707 0l-9 9c-0.195 0.195-0.195 0.512 0 0.707l9 9c0.098 0.098 0.226 0.146 0.354 0.146z'></path></svg>","<svg version='1.1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'><path d='M5 20c-0.128 0-0.256-0.049-0.354-0.146-0.195-0.195-0.195-0.512 0-0.707l8.646-8.646-8.646-8.646c-0.195-0.195-0.195-0.512 0-0.707s0.512-0.195 0.707 0l9 9c0.195 0.195 0.195 0.512 0 0.707l-9 9c-0.098 0.098-0.226 0.146-0.354 0.146z'></path></svg>"],
        responsive:{
            0:{
                items: 1
            },
            480:{
                items: 1
            },
            768:{
                items: 1
            },
            992:{
                items: 1
            },
            1200:{
                items : 1
            }
        }
    });

    //quantity up down
    $(document).on('click', '.quantity .input-grp-btn .value-button', function() {
        var $input = $(this).closest('.quantity').find('.input-text');

        if ($(this).hasClass('increase')) {
            $input.trigger('stepUp').trigger('change');
        }

        if ($(this).hasClass('decrease')) {
            $input.trigger('stepDown').trigger('change');
        }
    });
</script>

@endpush

@php
/*
$layout_page = shop_cart
**Variables:**
- $wishlist: no paginate
*/
@endphp
@extends($sc_templatePath.'.layout')

@section('block_main_content_center')

<div class="col-md-9 col-sm-12">
    <h3>{{ $title }}</h3>

    <div class="wishlist">
        @if (count($wishlist) ==0)
            {{ trans('front.empty_product') }}
        @else
        <table class="table">
            <thead>
                <tr>
                    <th class="product-remove">&nbsp;</th>
                    <th class="product-name">Product</th>
                    <th class="product-price">Price</th>
                </tr>
            </thead>
            <tbody>
                @foreach($wishlist as $item)
                    @php
                    $n = (isset($n)?$n:0);
                    $n++;
                    $product = $modelProduct->start()->getDetail($item->id, null, $item->storeId);
                    @endphp
                <tr class="cart-items">
                    <td class="product-remove" >
                        <a href="{{ sc_route('wishlist.remove',['id'=>$item->rowId]) }}" class="remove" onClick="return confirm('Confirm')" title="Remove Item" alt="Remove Item">×</a>
                    </td>
                    <td class="product-name" data-title="Product">
                        <a href="{{$product->getUrl() }}">
                            <img src="{{asset($product->getImage())}}" alt="{{ $product->name }}">
                        </a>
                        <h2 class="product-title">
                            <a href="{{$product->getUrl() }}">
                                {{ $product->name }},
                                @if ($item->options->count())
                                    (
                                        @foreach ($item->options as $keyAtt => $att)
                                        {{ $att }},
                                        @endforeach
                                    )
                                @endif
                            </a>
                        </h2>
                    </td>
                    <td class="product-price" data-title="Price">{!! $product->showPrice() !!}</td>
                    
                </tr>
                @endforeach
            </tbody>
        </table><!-- table end -->
        @endif
    </div><!-- wishlist -->
</div><!-- col end -->
@endsection

{{-- breadcrumb --}}
@section('breadcrumb')
<div class="box">
    <div class="pager-banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner-content">
                        <h1>{{ $title ?? '' }}</h1>
                        <div class="page-breadcrumb">
                            <ul>
                                <li class="parent"><a href="{{ sc_route('home') }}" rel="home">{{ trans('front.home') }}</a></li>
                                <li><span>{{ $title ?? '' }}</span></li>
                            </ul>
                        </div><!-- page breadcrumb end -->
                    </div><!-- banne content end -->
                </div><!-- col end -->
            </div><!-- row end -->
        </div><!-- container end -->
    </div><!-- page banner end -->
  </div><!-- box end -->
@endsection
{{-- //breadcrumb --}}


@push('styles')
{{-- Your css style --}}
@endpush

@push('scripts')
{{-- Your scripts --}}
@endpush